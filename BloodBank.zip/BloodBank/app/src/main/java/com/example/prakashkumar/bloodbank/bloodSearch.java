package com.example.prakashkumar.bloodbank;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class bloodSearch extends AppCompatActivity {
    String[] listitem;
    TextView t1,t2;
    Button b1,b2;
    dbHelper db1=new dbHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_search);
        b1=(Button)findViewById(R.id.selectGroup);
        t1=(TextView)findViewById(R.id.bloodg);
        b2=(Button)findViewById(R.id.bloodfind);
        t2=(TextView)findViewById(R.id.brecord);
   b1.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {
            listitem=new String[]{"A+","A-","B+","B-","O+","O-","AB+","AB-"};
           AlertDialog.Builder builder=new AlertDialog.Builder(bloodSearch.this);
           builder.setTitle("select Blood Group");
           builder.setSingleChoiceItems(listitem, -1, new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface dialogInterface, int i) {
                   t1.setText(listitem[i]);
                   dialogInterface.dismiss();
               }
           });
           builder.setNeutralButton("cancel", new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface dialogInterface, int i) {

               }
           });

           AlertDialog alertDialog=builder.create();
           alertDialog.show();
       }
   });

   b2.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {
           String bloodgroup=t1.getText().toString();
           List<contact> contacts = db1.searchBlood(bloodgroup);
           for (contact cn : contacts) {
               String log = "Name: "+cn.name()+" ,Mobile: " + cn.getMobile() + " ,Address: " + cn.getAddress();
               String str=null;
               // Writing Contacts to log
               if(log.equals(str)) {
                   t2.setText(str);
               }
               else{
                   t2.setText(log);
               }
           }

       }
   });

}
}