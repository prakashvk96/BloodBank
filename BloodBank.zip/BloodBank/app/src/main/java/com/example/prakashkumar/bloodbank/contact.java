/* contact.java*/
package com.example.prakashkumar.bloodbank;

/**
 * Created by PRAKASH KUMAR on 28-02-2018.
 */
 public class contact {

    String username,password,name,mobile,adhar,bgroup,address;


    public void setUname(String username){
        this.username=username;
    }

    public String getUname(){
        return this.username;
    }

    public void setname(String name){
        this.name=name;
    }

    public String name(){
        return this.name;
    }

    public void setPass(String password){
        this.password=password;
    }

    public String getPass(){
        return this.password;
    }

    public void setMobile(String mobile){
        this.mobile=mobile;
    }

    public String getMobile(){
        return this.mobile;
    }

    public void setAdhar(String adhar){
        this.adhar=adhar;
    }

    public String getAdhar(){
        return this.adhar;
    }

    public void setBgroup(String bgroup){
        this.bgroup=bgroup;
    }

    public String getBgroup(){
        return this.bgroup;
    }

    public void setAddress(String address){
        this.address=address;
    }

    public String getAddress(){
        return this.address;
    }

}


