/*bloodgroupChoice*/
package com.example.prakashkumar.bloodbank;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.widget.Toast;

/**
 * Created by PRAKASH KUMAR on 06-03-2018.
 */
public class bloodgroupChoice extends DialogFragment {

    final CharSequence[] items={"A+","A-","B+","B-","O+","O-","AB+","AB-"};
    String selection;
    public Dialog onCreateDialog(Bundle savedInstanceState){
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        builder.setTitle("Select Blood Group..").setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                switch (i){
                    case 0:
                        selection=(String) items[i];
                        break;

                    case 1:
                        selection=(String) items[i];
                        break;

                    case 2:
                        selection=(String) items[i];

                        break;
                    case 3:
                        selection=(String) items[i];
                        break;

                    case 4:
                        selection=(String) items[i];
                        break;

                    case 5:
                        selection=(String) items[i];
                        break;

                    case 6:
                        selection=(String) items[i];
                        break;

                    case 7:
                        selection=(String) items[i];
                        break;
                }
            }
        }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getActivity(),"Your selection is:"+selection,Toast.LENGTH_LONG).show();
            }
        });
        return builder.create();
    }


}
