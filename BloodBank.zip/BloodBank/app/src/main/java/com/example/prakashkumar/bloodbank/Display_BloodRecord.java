package com.example.prakashkumar.bloodbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Display_BloodRecord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display__blood_record);
    }
}
