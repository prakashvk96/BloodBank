package com.example.prakashkumar.bloodbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ambulanceSearch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ambulance_search);
    }
}
