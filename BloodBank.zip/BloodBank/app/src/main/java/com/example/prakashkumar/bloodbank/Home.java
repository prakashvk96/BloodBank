/*Home.java*/
package com.example.prakashkumar.bloodbank;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class Home extends AppCompatActivity {
    ImageButton b1,b2,b3,b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        TextView Textv = (TextView)findViewById(R.id.tv2);
        Intent iin= getIntent();
        Bundle b = iin.getExtras();
        b1=(ImageButton)findViewById(R.id.bloodButton);
        b2=(ImageButton)findViewById(R.id.anbulanceButton);
        b3=(ImageButton)findViewById(R.id.helpButton);
        b4=(ImageButton)findViewById(R.id.logoutButton);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Home.this,bloodSearch.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=null,chooser=null;

                        intent=new Intent(android.content.Intent.ACTION_VIEW);
                        intent.setData(Uri.parse("geo:20.5937,78.9629"));
                        chooser=Intent.createChooser(intent,"Launch Maps");
                        startActivity(chooser);


                          }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Home.this,help.class);
                startActivity(i);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                // session.isUserLoggedIn()== false;
                Intent in = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(in);
            }
        });

        if(b!=null)
        {
            String j =(String) b.get("welcome");
            Textv.setText("welcome "+j);
        }
    }
}
