package com.example.prakashkumar.bloodbank;

import android.os.AsyncTask;

/**
 * Created by PRAKASH KUMAR on 11-03-2018.
 */
/*public class BackgroundTask extends AsyncTask<String,void,void> {
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void doInBackground(String... voids) {

    }


}*/
