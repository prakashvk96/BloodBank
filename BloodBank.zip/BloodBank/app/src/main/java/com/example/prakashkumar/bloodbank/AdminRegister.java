/*AdminRegister.java*/

package com.example.prakashkumar.bloodbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.prakashkumar.bloodbank.MainActivity;
import com.example.prakashkumar.bloodbank.R;
import com.example.prakashkumar.bloodbank.contact;

public class AdminRegister extends AppCompatActivity {

    adminhelper phelper = new adminhelper(this);
    String[] listitem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_register);
        Button btn1=(Button) findViewById(R.id.adminregisterbutton);
        Button btn = (Button) findViewById(R.id.adminloginbutton);
        Button b1=(Button)findViewById(R.id.adminbsearch);
        final TextView t1 = (TextView) findViewById(R.id.adminbloodGroup);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(AdminRegister.this, AdminLogin.class);
                startActivity(intent);

            }
        });
        assert btn1 != null;
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText username = (EditText) findViewById(R.id.adminusername);
                EditText password = (EditText) findViewById(R.id.adminpass);
                EditText name = (EditText) findViewById(R.id.adminname);
                EditText mobileno = (EditText) findViewById(R.id.adminmobile);
                EditText adharno = (EditText) findViewById(R.id.adminadhar);
                TextView t1 = (TextView) findViewById(R.id.adminbloodGroup);

                EditText address = (EditText) findViewById(R.id.adminaddress);

                String Username = username.getText().toString();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

// onClick of button perform this simplest code.
                if (Username.matches(emailPattern))
                {
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                }
                String Password = password.getText().toString();
                if(TextUtils.isEmpty( Password)) {
                    password.setError("must not be empty");
                    return;
                }

                String Name = name.getText().toString();
                if(TextUtils.isEmpty(Name)) {
                    name.setError("must not be empty");
                    return;
                }

                String Mobile = mobileno.getText().toString();
                if(Mobile.length()!=10) {
                    // Toast.makeText(getApplicationContext(),"must be 10 digit", Toast.LENGTH_SHORT).show();
                    mobileno.setError("must be 10 digit");
                    return;
                }

                String Adhar = adharno.getText().toString();
                if(Adhar.length()!=12) {
                    // Toast.makeText(getApplicationContext(),"must be 10 digit", Toast.LENGTH_SHORT).show();
                    adharno.setError("must be 12 digit");
                    return;
                }



                String BloodGroup = t1.getText().toString();
                if(TextUtils.isEmpty(BloodGroup)) {
                    username.setError("must not be empty");
                    return;
                }

                String Address = address.getText().toString();
                if(TextUtils.isEmpty(Address)) {
                    username.setError("must not be empty");
                    return;
                }

                AdminContact c = new AdminContact();

                c.setUname(Username);
                c.setMobile(Mobile);
                c.setPass(Password);
                c.setAdhar(Adhar);
                c.setAddress(Address);
                c.setBgroup(BloodGroup);

                phelper.onInsert(c);
                Intent intent=new Intent(AdminRegister.this,MainActivity.class);
                startActivity(intent);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listitem = new String[]{"A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
                AlertDialog.Builder builder = new AlertDialog.Builder(AdminRegister.this);
                builder.setTitle("select Blood Group");
                builder.setSingleChoiceItems(listitem, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        t1.setText(listitem[i]);
                        dialogInterface.dismiss();
                    }
                });
                builder.setNeutralButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

    }
}

