/*userLogin.java*/
package com.example.prakashkumar.bloodbank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    dbHelper db1=new dbHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = (Button) findViewById(R.id.registerbutton);
        Button b2 = (Button) findViewById(R.id.loginbutton);
        Button b3 = (Button) findViewById(R.id.adminLogin);
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, register.class);
                startActivity(intent);

            }
        });



        if (b2 != null) {
            b2.setOnClickListener(new View.OnClickListener(){
                    public void onClick(View view) {
                        EditText uname=(EditText)findViewById(R.id.username);
                        EditText pass=(EditText)findViewById(R.id.pass);
                        String username=uname.getText().toString();
                        String password=pass.getText().toString();
                        String s=db1.searchPass(username);
                        if(password.equals(s)){
                            Intent i=new Intent(MainActivity.this,Home.class);
                            i.putExtra("welcome",username);
                            startActivity(i);
                        }
                        else{
                            Toast t=Toast.makeText(MainActivity.this,"username and pasword are not true",Toast.LENGTH_LONG);
                            t.show();
                        }

                    } });
        }

        b3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AdminLogin.class);
                startActivity(intent);

            }
        });
    }

    }


