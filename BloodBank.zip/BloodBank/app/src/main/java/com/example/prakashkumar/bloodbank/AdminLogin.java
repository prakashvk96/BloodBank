/*AdminLogin.java*/
package com.example.prakashkumar.bloodbank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminLogin extends AppCompatActivity {
    adminhelper db1=new adminhelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        Button b1 = (Button) findViewById(R.id.adminregister);
        Button b2 = (Button) findViewById(R.id.adminlogin);

        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(AdminLogin.this, AdminRegister.class);
                startActivity(intent);

            }
        });



        if (b2 != null) {
            b2.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view) {
                    EditText uname=(EditText)findViewById(R.id.adminusername);
                    EditText pass=(EditText)findViewById(R.id.adminpass);
                    String username=uname.getText().toString();
                    String password=pass.getText().toString();
                    String s=db1.searchPass(username);
                    if(password.equals(s)){
                        Intent i=new Intent(AdminLogin.this,Admin.class);
                        i.putExtra("welcome",username);
                        startActivity(i);
                    }
                    else{
                        Toast t=Toast.makeText(AdminLogin.this,"username and pasword are not true",Toast.LENGTH_LONG);
                        t.show();
                    }

                } });
        }


    }

}


