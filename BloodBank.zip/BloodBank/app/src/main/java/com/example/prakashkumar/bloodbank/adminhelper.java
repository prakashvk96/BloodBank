/* AdminHelper.java*/

package com.example.prakashkumar.bloodbank;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by PRAKASH KUMAR on 28-02-2018.
 */
public class adminhelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="BloodBank1";
    private static final int DATABASE_VERSION=1;

    private static final String TABLE_NAME2="admin";
    private static final String ID="id";
    private static final String USERNAME="sname";
    private static final String NAME="name";
    private static final String Adhar="adhar";
    private static final String Password="password";
    private static final String Mobile="mobile";
    private static final String BloodGroup="bloodgroup";
    private static final String Address="address";
    SQLiteDatabase db;

    adminhelper(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String q="CREATE TABLE " + TABLE_NAME2 + "( "+USERNAME+"," +Password+","+NAME+ "," +Adhar+"," +Mobile+","+BloodGroup+","+Address+")";
        db.execSQL(q);
        this.db=db;
    }

    public void onInsert(AdminContact c){
        db=this.getWritableDatabase();
        ContentValues value=new ContentValues();
        value.put(USERNAME,c.getUname());
        value.put(Password,c.getPass());
        value.put(NAME,c.getMobile());
        value.put(Adhar, c.getAdhar());
        value.put(Mobile,c.getMobile());
        value.put(BloodGroup,c.getBgroup());
        value.put(Address,c.getAddress());
        db.insert(TABLE_NAME2, null, value);
        db.close();

    }

    public String searchPass(String uname){
        db=this.getReadableDatabase();
        String query="Select "+USERNAME+","+Password+" from "+TABLE_NAME2;
        Cursor cursor=db.rawQuery(query,null);
        String s1,s2;
        s2="not found";
        if(cursor.moveToFirst()){
            do{
                s1=cursor.getString(0);
                if(s1.equals(uname)) {
                    s2 = cursor.getString(1);
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        return s2;
    }

    public String searchBlood(String uname){
        db=this.getReadableDatabase();
        String query="Select "+USERNAME+","+Password+" from "+TABLE_NAME2;
        Cursor cursor=db.rawQuery(query,null);
        String s1,s2;
        s2="not found";
        if(cursor.moveToFirst()){
            do{
                s1=cursor.getString(0);
                if(s1.equals(uname)) {
                    s2 = cursor.getString(1);
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        return s2;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int j, int i ) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        onCreate(db);
        /*this.onCreate(db);*/

    }
}

