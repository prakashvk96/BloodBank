package com.example.prakashkumar.bloodbank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button listblood=(Button)findViewById(R.id.listbloodbutton);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
    }
       public void displayblood(View view){
        startActivity(new Intent(this,Display_BloodRecord.class));
    }


}
